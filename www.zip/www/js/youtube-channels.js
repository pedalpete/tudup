var channel_json = {"channels":[
  {
    "owner":"TedTalks",
    "img":"http://www.learnoutloud.com/content/blog/TEDTalksTop100.jpg",
   "items": [
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/-xxEA26UzendEPL9v8mkjHdk4zE\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "aSL-iIskEFU"
     },
     "snippet": {
      "publishedAt": "2014-04-02T16:21:44.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Bill and Melinda Gates: Why giving away our wealth has been the most satisfying thing we've done...",
      "description": "n 1993, Bill and Melinda Gates—then engaged—took a walk on a beach in Zanzibar, and made a bold decision on how they would make sure that their wealth ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/aSL-iIskEFU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/aSL-iIskEFU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/aSL-iIskEFU/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/kSuvwUPpD1DzSuEZKVghVpZ07yY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "ZdDjexbxVzM"
     },
     "snippet": {
      "publishedAt": "2014-04-01T15:24:01.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Allan Adams: The discovery that could rewrite physics",
      "description": "On March 17, 2014, a group of physicists announced a thrilling discovery: the \"smoking gun\" data for the idea of an inflationary universe, a clue to the Big ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/ZdDjexbxVzM/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/ZdDjexbxVzM/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/ZdDjexbxVzM/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/9lmn-2rA5cC4fJRhNPravFHg-Uk\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "SCtdx0Xe1GA"
     },
     "snippet": {
      "publishedAt": "2014-04-01T15:20:05.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "TED, the Musical",
      "description": "Do you have a TED Talk inside, just bursting to come out? Take this tongue-in-cheek musical journey to \"Give Your Talk.\" A musical love letter to our speaker...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/SCtdx0Xe1GA/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/SCtdx0Xe1GA/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/SCtdx0Xe1GA/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/jO1d0IRqhbInIXIgyDH-fwIrhNA\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "mCZCok_u37w"
     },
     "snippet": {
      "publishedAt": "2014-03-31T17:02:43.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Geena Rocero: Why I must come out",
      "description": "When fashion model Geena Rocero first saw a professionally shot photo of herself clad in a bikini, she was beside herself. \"I thought...you have arrived!\" sh...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/mCZCok_u37w/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/mCZCok_u37w/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/mCZCok_u37w/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/mDFQX6K-UmxIY9TFvqudJlZlAGU\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "CDsNZJTWw0w"
     },
     "snippet": {
      "publishedAt": "2014-03-28T23:07:14.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Hugh Herr: The new bionics that let us run, climb and dance",
      "description": "Hugh Herr is building the next generation of bionic limbs, robotic prosthetics inspired by nature's own designs. Herr lost both legs in a climbing accident 3...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/z6bPr1iKsH1Zqb4Gl5-Ztxh4Ai8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "mAvSoNUgMno"
     },
     "snippet": {
      "publishedAt": "2014-03-27T18:26:57.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Del Harvey: The strangeness of scale at Twitter",
      "description": "When hundreds of thousands of Tweets are fired every second, a one-in-a-million chance — including unlikely sounding sounding scenarios that could harm ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/mAvSoNUgMno/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/mAvSoNUgMno/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/mAvSoNUgMno/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/vvdW7nvfF_KkscXGe5Yj8s8VhCY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "CfqO1U6lfDs"
     },
     "snippet": {
      "publishedAt": "2014-03-26T15:27:08.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Ed Yong: Suicidal wasps, zombie roaches and other parasite tales",
      "description": "We humans set a premium on our own free will and independence ... and yet there's a shadowy influence we might not be considering. As science writer Ed ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/CfqO1U6lfDs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/CfqO1U6lfDs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/CfqO1U6lfDs/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/ECoGspjB7NbC1-OVNsloLrx2ar8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "7qT3RpaBlJo"
     },
     "snippet": {
      "publishedAt": "2014-03-25T18:58:30.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Bran Ferren: To create for the ages, let's combine art and engineering",
      "description": "When Bran Ferren was just 9, his parents took him to see the Pantheon in Rome — and it changed everything. In that moment, he began to understand how the ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/7qT3RpaBlJo/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/7qT3RpaBlJo/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/7qT3RpaBlJo/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/u7RqxPdkMsmKQTW3mdpG4FNXVK8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "h4mmeN8gv9o"
     },
     "snippet": {
      "publishedAt": "2014-03-24T15:11:55.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Ziauddin Yousafzai: My daughter, Malala",
      "description": "Pakistani educator Ziauddin Yousafzai reminds the world of a simple truth that many don't want to hear: Women and men deserve equal opportunities for educati ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/h4mmeN8gv9o/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/h4mmeN8gv9o/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/h4mmeN8gv9o/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/f4uqm3QA9hj8J1QHb3nzPv1nkeo\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "mArrNRWQEso"
     },
     "snippet": {
      "publishedAt": "2014-03-22T06:40:46.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Larry Page: Where's Google going next?",
      "description": "Onstage at TED2014, Charlie Rose interviews Google CEO Larry Page about his far-off vision for the company. It includes aerial bikeways and internet balloons.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/mArrNRWQEso/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/mArrNRWQEso/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/mArrNRWQEso/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/9wh7aaIyIhi1NTFgileu1oc8eog\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "zLNXIXingyU"
     },
     "snippet": {
      "publishedAt": "2014-03-21T02:09:27.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Richard Ledgett: The NSA responds to Edward Snowden's TED Talk",
      "description": "After a surprise appearance by Edward Snowden at TED2014, Chris Anderson said: \"If the NSA wants to respond, please do.\" And yes, they did. Appearing by ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/zLNXIXingyU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/zLNXIXingyU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/zLNXIXingyU/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/_htJYX05Tw8fb6CCZNWvUCh2Wf4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "LFJ9WAHowcg"
     },
     "snippet": {
      "publishedAt": "2014-03-20T16:11:04.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Charmian Gooch: My wish: To launch a new era of openness in business",
      "description": "Anonymous companies protect corrupt individuals -- from notorious drug cartel leaders to nefarious arms dealers -- behind a shroud of mystery that makes it a...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/LFJ9WAHowcg/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/LFJ9WAHowcg/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/LFJ9WAHowcg/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/Toqmkpv1UwdMFqbxyJNW4xr5WdM\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "Zo62S0ulqhA"
     },
     "snippet": {
      "publishedAt": "2014-03-19T15:16:51.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Chris Hadfield: What I learned from going blind in space",
      "description": "There's an astronaut saying: In space, \"there is no problem so bad that you can't make it worse.\" So how do you deal with the complexity, the sheer pressure,...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Zo62S0ulqhA/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Zo62S0ulqhA/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Zo62S0ulqhA/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/Az1kLdrqNQzAkLl8jyDrBpZN9lY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "yVwAodrjZMY"
     },
     "snippet": {
      "publishedAt": "2014-03-19T00:10:11.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Edward Snowden: Here's how we take back the Internet",
      "description": "Appearing by telepresence robot, Edward Snowden speaks at TED2014 about surveillance and Internet freedom. The right to data privacy, he suggests, is not a ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/yVwAodrjZMY/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/yVwAodrjZMY/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/yVwAodrjZMY/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/eVo6skDwIGEd9dGZwJtIckimX3k\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "tzJYY2p0QIc"
     },
     "snippet": {
      "publishedAt": "2014-03-18T15:30:03.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Daniel Reisel: The neuroscience of restorative justice",
      "description": "Daniel Reisel studies the brains of criminal psychopaths (and mice). And he asks a big question: Instead of warehousing these criminals, shouldn't we be usin...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/tzJYY2p0QIc/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/tzJYY2p0QIc/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/tzJYY2p0QIc/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/V5QYVW-7B9MZJA4iuQAcGZqJ0MA\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "uk7gKixqVNU"
     },
     "snippet": {
      "publishedAt": "2014-03-17T18:47:35.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Steven Pinker and Rebecca Newberger Goldstein: The long reach of reason",
      "description": "Here's a TED first: an animated Socratic dialog! In a time when irrationality seems to rule both politics and culture, has reasoned thinking finally lost its...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/uk7gKixqVNU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/uk7gKixqVNU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/uk7gKixqVNU/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/E3I70Nplu-eh6MskHJZkIwiKS50\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "N39x_WTPix0"
     },
     "snippet": {
      "publishedAt": "2014-03-14T16:33:36.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Carin Bondar: The birds and the bees are just the beginning",
      "description": "Think you know a thing or two about sex? Think again. In this fascinating talk, biologist Carin Bondar lays out the surprising science behind how animals get...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/N39x_WTPix0/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/N39x_WTPix0/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/N39x_WTPix0/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/s1_j8DQVDJiccNkIyFu4Xyu8PoA\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "aT6vIq6_1OE"
     },
     "snippet": {
      "publishedAt": "2014-03-13T15:12:13.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Toby Shapshak: You don't need an app for that",
      "description": "Are the simplest phones the smartest? While the rest of the world is updating statuses and playing games on smartphones, Africa is developing useful SMS-base ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/aT6vIq6_1OE/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/aT6vIq6_1OE/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/aT6vIq6_1OE/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/dT2wwZzLQCcLquN3le5xy0rPBEo\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "tH5iEf9oxaI"
     },
     "snippet": {
      "publishedAt": "2014-03-12T15:50:21.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Anne-Marie Slaughter: Can we all \"have it all\"?",
      "description": "Public policy expert Anne-Marie Slaughter made waves with her 2012 article, \"Why women still can't have it all.\" But really, is this only a question for wome...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/tH5iEf9oxaI/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/tH5iEf9oxaI/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/tH5iEf9oxaI/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/uR6FTQfQ7Lh-QWl39H1vlTq2NUU\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "-Z-ul0GzzM4"
     },
     "snippet": {
      "publishedAt": "2014-03-10T15:40:21.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Ajit Narayanan: A word game to communicate in any language",
      "description": "While working with kids who have trouble speaking, Ajit Narayanan sketched out a way to think about language in pictures, to relate words and concepts in \"ma.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/-Z-ul0GzzM4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/-Z-ul0GzzM4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/-Z-ul0GzzM4/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/OKNIc6AIlOhIcfxB1g0AEjVawHU\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "h8cF5QPPmWU"
     },
     "snippet": {
      "publishedAt": "2014-03-07T17:51:59.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Manu Prakash: A 50-cent microscope that folds like origami",
      "description": "Perhaps you've punched out a paper doll or folded an origami swan? TED Fellow Manu Prakash and his team have created a microscope made of paper that's ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/h8cF5QPPmWU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/h8cF5QPPmWU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/h8cF5QPPmWU/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/qhfjI113juNZhLmCFE8IS4J6eVc\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "13rqtiAPISY"
     },
     "snippet": {
      "publishedAt": "2014-03-06T16:48:10.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Gabriel Barcia-Colombo: My DNA vending machine",
      "description": "Vending machines generally offer up sodas, candy bars and chips. Not so for the one created by TED Fellow Gabe Barcia-Colombo. This artist has dreamed up ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/13rqtiAPISY/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/13rqtiAPISY/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/13rqtiAPISY/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/L3XiQZl6UN49-cJyN5FzidxRBgM\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "FrxDrpi1XNU"
     },
     "snippet": {
      "publishedAt": "2014-03-05T19:45:22.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Christopher Soghoian: Government surveillance — this is just the beginning",
      "description": "Privacy researcher Christopher Soghoian sees the landscape of government surveillance shifting beneath our feet, as an industry grows to support monitoring p.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/FrxDrpi1XNU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/FrxDrpi1XNU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/FrxDrpi1XNU/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/KLb3DZO6w58xPg6dCRLfAPl-rC8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "vNDhu2uqfdo"
     },
     "snippet": {
      "publishedAt": "2014-03-03T17:07:16.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Mary Lou Jepsen: Could future devices read images from our brains?",
      "description": "As an expert on cutting-edge digital displays, Mary Lou Jepsen studies how to show our most creative ideas on screens. And as a brain surgery patient herself...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/vNDhu2uqfdo/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/vNDhu2uqfdo/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/vNDhu2uqfdo/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/lHhf4QpV0-L4ujtHdQ3t_XcrjOg\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PLOGi5-fAu8bHBh9lg_4t-qcCa8l625Rhq"
     },
     "snippet": {
      "publishedAt": "2014-02-28T19:44:45.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Should we redesign humans?",
      "description": "The age of bioengineering is upon us, with scientists' understanding of how to engineer cells, tissues and organs improving at a rapid pace. Here, how this c...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/CDsNZJTWw0w/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/DX1FYkm0KTGSBJct-YxWzlDN6p4\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PLOGi5-fAu8bFB2BREaY3WYXxwp0eanfMR"
     },
     "snippet": {
      "publishedAt": "2014-02-28T19:37:26.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "In the mood for love",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/OYfoGTIG7pY/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/OYfoGTIG7pY/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/OYfoGTIG7pY/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/DVMOhLHqOeDjZ2O4skPHdIEir1c\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PLOGi5-fAu8bF47nouZdRGysPRnVlyDWwS"
     },
     "snippet": {
      "publishedAt": "2014-02-28T19:34:05.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "The forecast calls for...",
      "description": "Why is it that the weather is so often a subject of conversation? Because it's a shared experience amongst all those around us. Here, talks about the weather.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/lhP52caGW6s/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/lhP52caGW6s/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/lhP52caGW6s/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/OX2HTTedRO-IHsu7lsbRQy6m_2c\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PLOGi5-fAu8bHHdsBDrCYWSB25fmf-tInK"
     },
     "snippet": {
      "publishedAt": "2014-02-28T19:30:43.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "MOOCs 101",
      "description": "Given that it's the internet age and all, why should classrooms look exactly the way they have for centuries? Here, TED speakers on what can happen when we ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/iE7YRHxwoDs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/iE7YRHxwoDs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/iE7YRHxwoDs/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/EWamAixBm3YJ-5H89ezk5gJGBUE\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PLOGi5-fAu8bHnnG6iuIUMOuZRaBKEal7O"
     },
     "snippet": {
      "publishedAt": "2014-02-28T19:24:25.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "How leaders inspire",
      "description": "What makes a great leader? The ability to rule with an iron fist? Being well-liked? Or maybe just having a really loud voice? These TED speakers each offer m...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/qp0HIF3SfI4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/qp0HIF3SfI4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/qp0HIF3SfI4/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/orZjdgPxauiO8J0m80cO8JhlUx0\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "tZYkjaKNr_o"
     },
     "snippet": {
      "publishedAt": "2014-02-28T16:06:06.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Annette Heuser: The 3 agencies with the power to make or break economies",
      "description": "The way we rate national economies is all wrong, says rating agency reformer Annette Heuser. With mysterious and obscure methods, three private US-based ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/tZYkjaKNr_o/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/tZYkjaKNr_o/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/tZYkjaKNr_o/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/Xjb13x6cXtPBf4yNweiJoDs655E\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "NoCOagL69_s"
     },
     "snippet": {
      "publishedAt": "2014-02-26T16:53:45.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Michael Metcalfe: We need money for aid. So let's print it.",
      "description": "During the financial crisis, the central banks of the United States, United Kingdom and Japan created $3.7 trillion in order to buy assets and encourage inve...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/NoCOagL69_s/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/NoCOagL69_s/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/NoCOagL69_s/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/rTwyxxBVMUX98rHI65qNBIVDelY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "QeAGu40vZzI"
     },
     "snippet": {
      "publishedAt": "2014-02-25T17:18:22.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Catherine Bracy: Why good hackers make good citizens",
      "description": "Hacking is about more than mischief-making or political subversion. As Catherine Bracy describes in this spirited talk, it can be just as much a force for go...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/QeAGu40vZzI/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/QeAGu40vZzI/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/QeAGu40vZzI/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/HkcEX6MOv7jio8WsTqLW0MJo05g\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "0FQXicAGy5U"
     },
     "snippet": {
      "publishedAt": "2014-02-24T18:09:12.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Siddharthan Chandran: Can the damaged brain repair itself?",
      "description": "After a traumatic brain injury, it sometimes happens that the brain can repair itself, building new brain cells to replace damaged ones. But the repair doesn...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/0FQXicAGy5U/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/0FQXicAGy5U/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/0FQXicAGy5U/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/0k00yibp-SWsBOzDV55EA7M7T9I\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "uq83lU6nuS8"
     },
     "snippet": {
      "publishedAt": "2014-02-21T16:33:16.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Ash Beckham: We're all hiding something. Let's find the courage to open up",
      "description": "In this touching talk, Ash Beckham offers a fresh approach to empathy and openness. It starts with understanding that everyone, at some point in their life, ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/uq83lU6nuS8/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/uq83lU6nuS8/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/uq83lU6nuS8/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/mtnjfBs4tUU1-M3QM3N-Gd2jwV4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "LJhklPJz9U8"
     },
     "snippet": {
      "publishedAt": "2014-02-20T17:22:58.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Christopher Ryan: Are we designed to be sexual omnivores?",
      "description": "An idea permeates our modern view of relationships: that men and women have always paired off in sexually exclusive relationships. But before the dawn of agr.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/LJhklPJz9U8/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/LJhklPJz9U8/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/LJhklPJz9U8/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/v7D0M1fTSITqzhDFmGpFw98I7Lc\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "SpTGUT-Fvf4"
     },
     "snippet": {
      "publishedAt": "2014-02-19T18:50:16.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Fields Wicker-Miurin: Learning from leadership's missing manual",
      "description": "Leadership doesn't have a user's manual, but Fields Wicker-Miurin says stories of remarkable, local leaders are the next best thing. At a TED salon in London...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/SpTGUT-Fvf4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/SpTGUT-Fvf4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/SpTGUT-Fvf4/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/WbUj2YjbJ0-0DAXolkhEtf_7_v0\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "aUYSDEYdmzw"
     },
     "snippet": {
      "publishedAt": "2014-02-19T17:09:18.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Roselinde Torres: What it takes to be a great leader",
      "description": "There are many leadership programs available today, from 1-day workshops to corporate training programs. But chances are, these won't really help. In this cl...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/aUYSDEYdmzw/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/aUYSDEYdmzw/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/aUYSDEYdmzw/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/0N_wsM4KKfJ2gzzBJ7qjB7SE1r4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "fYUaWgVF2XA"
     },
     "snippet": {
      "publishedAt": "2014-02-18T16:25:05.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Molly Stevens: A new way to grow bone",
      "description": "What does it take to regrow bone in mass quantities? Typical bone regeneration — wherein bone is taken from a patient's hip and grafted onto damaged bone ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/fYUaWgVF2XA/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/fYUaWgVF2XA/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/fYUaWgVF2XA/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/5PX1XuW-083-jeKMLia9wVVl9zY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "dJgiYBdD2VA"
     },
     "snippet": {
      "publishedAt": "2014-02-14T16:36:51.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Yann Dall'Aglio: Love -- you're doing it wrong",
      "description": "In this delightful talk, philosopher Yann Dall'Aglio explores the universal search for tenderness and connection in a world that's ever more focused on the i...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/dJgiYBdD2VA/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/dJgiYBdD2VA/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/dJgiYBdD2VA/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/3ZlDy4VcVi7pEcLhG8zOyDachNY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "d38LKbYfWrs"
     },
     "snippet": {
      "publishedAt": "2014-02-13T16:37:48.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Rupal Patel: Synthetic voices, as unique as fingerprints",
      "description": "Many of those with severe speech disorders use a computerized device to communicate. Yet they choose between only a few voice options. That's why Stephen ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/d38LKbYfWrs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/d38LKbYfWrs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/d38LKbYfWrs/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/kAym9vTdhZycOvxU_R3lyHyYzUc\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "rpOwTspdwkI"
     },
     "snippet": {
      "publishedAt": "2014-02-12T17:21:47.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Chris McKnett: The investment logic for sustainability",
      "description": "Sustainability is pretty clearly one of the world's most important goals; but what groups can really make environmental progress in leaps and bounds? Chris M...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/rpOwTspdwkI/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/rpOwTspdwkI/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/rpOwTspdwkI/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/uqtPB5ZmQ9Dt6v2s5FVB0L_ruNQ\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "2L4B-Vpvx1A"
     },
     "snippet": {
      "publishedAt": "2014-02-11T16:37:48.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Leyla Acaroglu: Paper beats plastic? How to rethink environmental folklore",
      "description": "Most of us want to do the right thing when it comes to the environment. But things aren't as simple as opting for the paper bag, says sustainability strategi...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/2L4B-Vpvx1A/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/2L4B-Vpvx1A/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/2L4B-Vpvx1A/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/QFkJx518APTjWLVtNLI0Y-bSTHo\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "Br1AIvMrvAE"
     },
     "snippet": {
      "publishedAt": "2014-02-10T16:32:45.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "David Puttnam: What happens when the media's priority is profit?",
      "description": "In this thoughtful talk, David Puttnam asks a big question about the media: Does it have a moral imperative to create informed citizens, or is it free to pur...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Br1AIvMrvAE/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Br1AIvMrvAE/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Br1AIvMrvAE/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/YkFhYfDAVSPoFP9CLaxaxBQ_Mqw\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "PrZwUTdFmis"
     },
     "snippet": {
      "publishedAt": "2014-02-07T16:27:30.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Aparna Rao: Art that craves your attention",
      "description": "In this charming talk, artist Aparna Rao shows us her latest work: cool, cartoony sculptures (with neat robotic tricks underneath them) that play with your p...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/PrZwUTdFmis/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/PrZwUTdFmis/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/PrZwUTdFmis/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/g5DJnK5-DNL859ag_Hu14iiYawk\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "ue2ZEmTJ_Xo"
     },
     "snippet": {
      "publishedAt": "2014-02-06T18:19:28.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Alex Wissner-Gross: A new equation for intelligence",
      "description": "Is there an equation for intelligence? Yes. It's F = T ∇ Sτ. In a fascinating and informative talk, physicist and computer scientist Alex Wissner-Gross expla...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/ue2ZEmTJ_Xo/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/ue2ZEmTJ_Xo/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/ue2ZEmTJ_Xo/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/EGbTNFHaY3bIJUZgUlWK99VZLic\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "aG-ZeDqG8Zk"
     },
     "snippet": {
      "publishedAt": "2014-02-05T16:39:39.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Teddy Cruz: How architectural innovations migrate across borders",
      "description": "As the world's cities undergo explosive growth, inequality is intensifying. Wealthy neighborhoods and impoverished slums grow side by side, the gap between t...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/aG-ZeDqG8Zk/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/aG-ZeDqG8Zk/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/aG-ZeDqG8Zk/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/Cu8yKjy4upIdGFG4xWpiXwFTiw4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "7pVPmmwSeJQ"
     },
     "snippet": {
      "publishedAt": "2014-02-04T17:23:32.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Dan Berkenstock: The world is one big dataset. Now, how to photograph it ...",
      "description": "We're all familiar with satellite imagery, but what we might now know is that much of it is out of date. That's because satellites are big and expensive, so ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/7pVPmmwSeJQ/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/7pVPmmwSeJQ/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/7pVPmmwSeJQ/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/kw8vFHc6WOuCy1U9a3Ka2pQf5pY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "Li4-1yyrsTI"
     },
     "snippet": {
      "publishedAt": "2014-02-03T16:48:00.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Esta Soler: How we turned the tide on domestic violence (Hint: the Polaroid helped)",
      "description": "When Esta Soler lobbied for a bill outlawing domestic violence in 1984, one politician called it the \"Take the Fun Out of Marriage Act.\" \"If only I had Twitt...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Li4-1yyrsTI/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Li4-1yyrsTI/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Li4-1yyrsTI/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/_ASm_7pVOk3VIKva5RclydxOAaU\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "jVcaTtJmRNs"
     },
     "snippet": {
      "publishedAt": "2014-01-31T16:54:01.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Maya Penn: Meet a young entrepreneur, cartoonist, designer, activist ...",
      "description": "Maya Penn started her first company when she was 8 years old, and thinks deeply about how to be responsible both to her customers and to the planet.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/jVcaTtJmRNs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/jVcaTtJmRNs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/jVcaTtJmRNs/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/otJhsgAlz_QMvJ0Bl6oCZC86PL8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "0Y8-IzP01lw"
     },
     "snippet": {
      "publishedAt": "2014-01-30T17:11:49.000Z",
      "channelId": "UCAuUUnT6oDeKwE6v1NGQxug",
      "title": "Nicolas Perony: Puppies! Now that I've got your attention, complexity theory",
      "description": "Animal behavior isn't complicated, but it is complex. Nicolas Perony studies how individual animals -- be they Scottish Terriers, bats or meerkats -- follow ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/0Y8-IzP01lw/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/0Y8-IzP01lw/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/0Y8-IzP01lw/hqdefault.jpg"
       }
      },
      "channelTitle": "TEDtalksDirector",
      "liveBroadcastContent": "none"
     }
    }
   ]
  },
  {
    "owner":"upworthy",
    "img": "http://www.upworthy.com/assets/logo-large-e8b782e3f018a28201292ea7c58d4cf0.png",
    "items": [
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/5oC4AKM2jv_-g0N4werx1CX4jMY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "6uXOozRjRM4"
     },
     "snippet": {
      "publishedAt": "2014-04-01T17:13:25.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Raise the River - Save the Colorado River Delta",
      "description": "It's Robert Redford vs. Will Ferrell in this battle to Raise the River or Move the Ocean to save the Colorado River delta. Like that? We did, too. That's why...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/6uXOozRjRM4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/6uXOozRjRM4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/6uXOozRjRM4/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/kc71CLKglp9QJhp3Yw3fIjO9fCU\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "b3geNgWtBqg"
     },
     "snippet": {
      "publishedAt": "2014-03-28T20:25:23.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Eyewitnesses Explain The Crimes Of North Korea",
      "description": "A new United Nations report has found that crimes against humanity are occurring in North Korea and calls for an international tribunal to investigate and ho...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/b3geNgWtBqg/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/b3geNgWtBqg/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/b3geNgWtBqg/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/YZFyCbelGveE7OaEtMwLuHUm_-A\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "m2zPRlXFt44"
     },
     "snippet": {
      "publishedAt": "2014-03-28T20:02:04.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "How Social Media Is Changing Saudi Arabia",
      "description": "Activists in Saudi Arabia face a repressive and intolerant government as they advocate popular political participation, judicial reform, and an end to discri...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/m2zPRlXFt44/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/m2zPRlXFt44/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/m2zPRlXFt44/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/al9gsaRT89quOafa0AFFxXw2-0k\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "Ba8hZ-9fa74"
     },
     "snippet": {
      "publishedAt": "2014-03-28T19:24:41.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "End Child Marriage in Malawi",
      "description": "Malawi's first woman president, Joyce Banda, who took office in April 2012, should publicly support prompt enactment of the Marriage, Divorce, and Family Rel...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Ba8hZ-9fa74/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Ba8hZ-9fa74/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Ba8hZ-9fa74/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/TVIrvgA1olcZObIt372JBg8n4Qg\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "xMDcNO8vGwU"
     },
     "snippet": {
      "publishedAt": "2014-03-28T18:56:09.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Should We Be Labeling Children Sex Offenders For Life?",
      "description": "See the full report: http://www.hrw.org/reports/2013/05/01/raised-registry Did that make you think? Us, too. That's why we think you should check out our par...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/fiS4rR4yeDg-hjFfevwzLlbPsvs\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "aJ61qq2wnYQ"
     },
     "snippet": {
      "publishedAt": "2014-03-18T19:13:08.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Demand Conflict-Free Electronics, Help End The War In The Congo",
      "description": "\"Major electronics companies need to step up and become part of the solution, not the problem.\" The link between technology and the ongoing war in the ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/aJ61qq2wnYQ/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/aJ61qq2wnYQ/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/aJ61qq2wnYQ/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/TovHc41AMHDusRSezr3WFOQ2-w4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "LTjsHNtlhF4"
     },
     "snippet": {
      "publishedAt": "2014-03-18T17:24:45.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "You Can Help End Child Slavery In India",
      "description": "The Child And Adolescent Labour Abolition Bill is currently sitting before the Indian Parliament. It would go a long way towards ending child slavery in Indi...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/LTjsHNtlhF4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/LTjsHNtlhF4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/LTjsHNtlhF4/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/RFi50eabDV-_nx-zPXP3PBobOCg\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "JZpl3c4uJGo"
     },
     "snippet": {
      "publishedAt": "2014-03-18T16:26:29.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Walk Free - Join The Movement To End Modern Slavery",
      "description": "Never underestimate the power of one person taking a stand against slavery. Like that? We did, too. That's why we think you should check out our partner Walk...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/JZpl3c4uJGo/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/JZpl3c4uJGo/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/JZpl3c4uJGo/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/Y6xUJfJcnEC1URw1Nn8Q6lpOMA4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "qCDV7IUqSfs"
     },
     "snippet": {
      "publishedAt": "2014-03-14T16:52:29.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "The Next American Revolution",
      "description": "Like that? We did, too. That's why we think you should check out our partner Democracy Collaborative and their film, The Next American Revolution, at the lin...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/qCDV7IUqSfs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/qCDV7IUqSfs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/qCDV7IUqSfs/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/eatw5KnmlME2YPM0oeKpXsid9F8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "VpMvXtvYO0s"
     },
     "snippet": {
      "publishedAt": "2014-03-13T22:19:22.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "His Star Student Wants To Go To College. She's Not Getting In. - Clint Smith, Poet",
      "description": "Clint Smith teaches in a challenging school. One of his biggest challenges is helping students like the one he speaks about in this poem, the daughter of ill...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/VpMvXtvYO0s/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/VpMvXtvYO0s/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/VpMvXtvYO0s/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/t78YCj8ExRDXVTEO_89AbTKSSv4\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh445gcmioY9D5eBlh4SXH7ia_"
     },
     "snippet": {
      "publishedAt": "2014-03-04T21:29:55.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Guns And Crime",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/xMDcNO8vGwU/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/ge3QO9wDV7uwgGkZTtx_9IeYqkk\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "dIqiQ8Vz_ps"
     },
     "snippet": {
      "publishedAt": "2014-03-04T17:12:49.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Did You Know That Schools Used To Rename Mexican Children More American Names?",
      "description": "Back in simpler times (or more awful, you decide), Mexican children with \"Mexican-sounding\" names had their names Anglicized, or made into a more American ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/dIqiQ8Vz_ps/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/dIqiQ8Vz_ps/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/dIqiQ8Vz_ps/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/a5kHBUlYtEC3iQkFJ1knMzd69mA\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "8mm5jElMs2g"
     },
     "snippet": {
      "publishedAt": "2014-03-03T18:57:09.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Ever Heard Of A Medical Desert? Belhaven, NC Is Fighting Not To Become One.",
      "description": "For being a country that spends so much money on health care, it's kinda crazy to think that in some places in the United States, like Belhaven, NC if nothin...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/8mm5jElMs2g/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/8mm5jElMs2g/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/8mm5jElMs2g/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/DYZSpaV-jht1_VivpuXhVeCkHUI\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "8T4SpmxXHBc"
     },
     "snippet": {
      "publishedAt": "2014-03-03T16:54:06.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "He Lost The Vote But Won History With A Few Simple Words That Helped Others Pave The Way To Change",
      "description": "If you haven't met Rev. William Barber, then you are in for a treat. This is not your grandma's Sunday service, that's for sure. (Or, if it is ... then you t...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/8T4SpmxXHBc/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/8T4SpmxXHBc/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/8T4SpmxXHBc/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/WBj-AOepX4rBb9yD5HIwTMOf1-0\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "0lLf6qakrTw"
     },
     "snippet": {
      "publishedAt": "2014-02-19T23:00:15.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "He Walked Into A Segregated Library. He Wanted To Be An Astronaut. Mission Accomplished.",
      "description": "Ronald McNair grew up in Lake City, SC. He grew up to become an astronaut. Tragically, he was on the Challenger mission, which exploded seconds after ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/0lLf6qakrTw/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/0lLf6qakrTw/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/0lLf6qakrTw/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/HTOb3SzsPfLDZBwtJSBVmB3BwmI\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh445OzBBJ-YjOG1CeA_UQnsuO"
     },
     "snippet": {
      "publishedAt": "2014-02-07T00:35:51.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "LGBTQ",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/vbN2bUgg1ws/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/vbN2bUgg1ws/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/vbN2bUgg1ws/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/aRqkAgGOmIhtI59QnT4HXlbML1c\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh446C875AyHSC0gvx81FwA2I3"
     },
     "snippet": {
      "publishedAt": "2014-02-07T00:35:29.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Health",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Ju-q4OnBtNU/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Ju-q4OnBtNU/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Ju-q4OnBtNU/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/enxeus7v1xOSpOf2D2G2LNzSRyQ\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh446wNKtzCyHXype9E7u2bMHH"
     },
     "snippet": {
      "publishedAt": "2014-02-07T00:35:00.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Gender",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/ZPCkfARH2eE/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/ZPCkfARH2eE/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/ZPCkfARH2eE/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/X9l__T6QSKCZWIIvWuHsRfYXmJY\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh447QgB1oYA6mKOu4iOLUuPTs"
     },
     "snippet": {
      "publishedAt": "2014-02-07T00:09:43.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Environment",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/__-ZN9YQ4ms/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/__-ZN9YQ4ms/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/__-ZN9YQ4ms/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/gInUGhc5vGapOcFY_IlylXHAC8Y\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh446ICYYMsFXdMi0YURoC2YqJ"
     },
     "snippet": {
      "publishedAt": "2014-02-06T23:54:44.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Economy",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/luLt8mfhFYs/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/luLt8mfhFYs/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/luLt8mfhFYs/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/WWeRcGwpymBYZt5dss523NCTCCk\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh447UrKUp-JsZxFqAqUp-L5LR"
     },
     "snippet": {
      "publishedAt": "2014-02-06T23:22:36.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Diversity",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/VoP0ox_Jw_w/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/VoP0ox_Jw_w/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/VoP0ox_Jw_w/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/wmqEkZCbbYjQrtT5CEbEMMjVV6U\"",
     "id": {
      "kind": "youtube#playlist",
      "playlistId": "PL_W1Mq2lh447q_HVY76WOCp0OX5bkF75E"
     },
     "snippet": {
      "publishedAt": "2014-02-05T18:42:51.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Best Of Upworthy",
      "description": "Take a gander at the cream of the crop, the top of the heap, the bee's knees, the most meaningful, most important, most entertaining videos we've found on th...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/V4UWxlVvT1A/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/V4UWxlVvT1A/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/V4UWxlVvT1A/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/xDXLEECmAAQIGgM-vYo8DOYPJMc\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "BQnW0TAblTY"
     },
     "snippet": {
      "publishedAt": "2013-11-25T22:10:47.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Ash Beckham",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/BQnW0TAblTY/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/BQnW0TAblTY/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/BQnW0TAblTY/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/F9j_hHC7a2XAClZnJTiJUkhXPEM\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "AtMuUoEbMN0"
     },
     "snippet": {
      "publishedAt": "2013-09-18T21:36:55.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Rachel Maddow On Mass Shootings",
      "description": "",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/AtMuUoEbMN0/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/AtMuUoEbMN0/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/AtMuUoEbMN0/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/M8C4Yl-sKScBJTOb9cpkHqCgcfg\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "0si9uWNaxE0"
     },
     "snippet": {
      "publishedAt": "2013-09-06T20:28:19.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Chris Hayes On American Intervention In Syria",
      "description": "Uploaded with permission from \"All In With Chris Hayes.\"",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/0si9uWNaxE0/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/0si9uWNaxE0/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/0si9uWNaxE0/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/3VT2G4nMsPV2RB2vaeZBzeyEPXA\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "KGAMnOjfnkE"
     },
     "snippet": {
      "publishedAt": "2013-04-16T21:20:10.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "A Former Tea Party Patriot Gives A Speech That Will Make Progressives Stand Up And Cheer",
      "description": "Tea Party Patriots co-founder Mark Meckler (who has since resigned from the organization) might be a conservative at heart, but this recent exchange from Sea...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/KGAMnOjfnkE/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/KGAMnOjfnkE/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/KGAMnOjfnkE/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/9yG3IaXL-4D9UCj0PlmR5bc3Fr4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "Trc-xAehwco"
     },
     "snippet": {
      "publishedAt": "2013-04-16T21:19:20.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "That Crazy Moment When A Progressive And A Tea Partier Are In Complete Agreement",
      "description": "Mark Meckler (co-founder, Tea Party Patriots) and Joan Blades (co-founder, MoveOn.org) come from opposite ends of the political spectrum and should be ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/Trc-xAehwco/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/Trc-xAehwco/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/Trc-xAehwco/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/er04QzsmMuIkUWdBDVM44vgdKfo\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "y3oKWWgY1DQ"
     },
     "snippet": {
      "publishedAt": "2013-02-27T16:07:01.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "An Open Letter From A 12-Year-Old Eagle Scout To The Boy Scouts",
      "description": "July 17th, 2012: The Boy Scouts Of America officially decides to ban gay boy scouts and leaders. September 21, 2012: Intel pulls funding for Boy Scouts. Nove...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/y3oKWWgY1DQ/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/y3oKWWgY1DQ/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/y3oKWWgY1DQ/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/u6HYmd4iiuzNdGBj7E6jDgu75W4\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "rjNCtzaQxV8"
     },
     "snippet": {
      "publishedAt": "2012-12-14T01:21:29.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "The Top 5 Ways To Be 'Traditionally Married' According To The Bible",
      "description": "I don't think \"traditional marriage\" means what you think it means.",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/rjNCtzaQxV8/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/rjNCtzaQxV8/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/rjNCtzaQxV8/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/V4hK8eXHN-jSkQclkIlDRfnDIj8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "6qGxEC6AweY"
     },
     "snippet": {
      "publishedAt": "2012-12-14T01:20:17.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "We Have Been Misled By An Erroneous Map Of The World For 500 Years",
      "description": "Who did Africa piss off? The smaller something looks on a map, the more likely it is to be undervalued. Also, check out this size-accurate version of the wor...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/6qGxEC6AweY/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/6qGxEC6AweY/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/6qGxEC6AweY/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/8KqnhrNFDP-UgLDDS9MGIB49OYk\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "tEAireuPCS4"
     },
     "snippet": {
      "publishedAt": "2012-11-19T19:28:11.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "So You Stole A VCR From Sears One Time In 1990. Should You Really STILL Be In Jail?",
      "description": "https://www.upworthy.com/ For a country that brands itself as the \"land of the free,\" we certainly seem to have a lot of prisoners. Let's just check and see ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/tEAireuPCS4/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/tEAireuPCS4/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/tEAireuPCS4/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/K1BfLPBBGCazTOr43iUNBvgXRRw\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "zDW5OeLcT4A"
     },
     "snippet": {
      "publishedAt": "2012-11-19T19:28:12.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "War On Prescription Drugs",
      "description": "https://www.upworthy.com/ The \"war on drugs\" would probably feel a whole lot more relevant if the drugs that are actually killing people were the ones the wa...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/zDW5OeLcT4A/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/zDW5OeLcT4A/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/zDW5OeLcT4A/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/I1KO_R-aVNR-J809vDCWtXrWQmg\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "P5R9rC2O6Ug"
     },
     "snippet": {
      "publishedAt": "2012-11-19T19:26:08.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Someone Call Security, A Bunch Of Women Just Broke Into Congress",
      "description": "https://www.upworthy.com/ The 2013 Congress isn't just more diverse in terms of gender, it's more diverse in terms of EVERYTHING. On behalf of Upworthy, ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/P5R9rC2O6Ug/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/P5R9rC2O6Ug/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/P5R9rC2O6Ug/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/WEK4ORpTiaqAMJHqa24Arh0x3J8\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "68TECa0oHUQ"
     },
     "snippet": {
      "publishedAt": "2012-11-19T19:26:08.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "No Matter How Bad You Are With Money, You'll Never Be As Bad As Karl Rove",
      "description": "https://www.upworthy.com/ You've probably heard the term 'money in politics' a lot recently, and this election saw some of the most blatant attempts to buy p...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/68TECa0oHUQ/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/68TECa0oHUQ/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/68TECa0oHUQ/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/AonGD5gUiJCk5Etp6WzpJW8JhFg\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "CXGNns6Zejw"
     },
     "snippet": {
      "publishedAt": "2012-11-19T19:23:22.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "The Famous Pot Smokers Who Did NOTHING With Their Lives",
      "description": "https://www.upworthy.com/ Marijuana gets a pretty bad rap. People campaign against it for being a drug, for leading to a couch-potato lifestyle, and a host o...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/CXGNns6Zejw/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/CXGNns6Zejw/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/CXGNns6Zejw/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/YmO5tqj5_NWfdBPd3zdcS59rRNI\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "kFPTmlcU1yI"
     },
     "snippet": {
      "publishedAt": "2012-11-06T18:53:25.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "FEMA and Hurricane Sandy",
      "description": "https://www.upworthy.com/ Hurricane Sandy was a devastating force of nature. Having a national agency to respond to emergencies is exactly the kind of thing ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/kFPTmlcU1yI/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/kFPTmlcU1yI/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/kFPTmlcU1yI/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/ybC8m8pahROG3qGvbAiJxU9X8cY\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "OiivZnyBSOk"
     },
     "snippet": {
      "publishedAt": "2012-10-30T17:50:57.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Why Homophobia Is Just Like Riding A Bicycle",
      "description": "https://www.upworthy.com/ Discussing gay marriage with someone who has been against it their whole life is a difficult task. Dr. Rollie Williams* talks turke...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/OiivZnyBSOk/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/OiivZnyBSOk/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/OiivZnyBSOk/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/HUHpwfTfUUFUYCSkgLeoKjq2g_Q\"",
     "id": {
      "kind": "youtube#video",
      "videoId": "rKx2jESqcVc"
     },
     "snippet": {
      "publishedAt": "2012-10-25T17:55:36.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "I Can't Buy A Bra Without Some Feminist Trying To Burn It",
      "description": "https://www.upworthy.com/ It's pretty hard to have a conversation about something when you're talking about two completely different things. For the sake of ...",
      "thumbnails": {
       "default": {
        "url": "https://i.ytimg.com/vi/rKx2jESqcVc/default.jpg"
       },
       "medium": {
        "url": "https://i.ytimg.com/vi/rKx2jESqcVc/mqdefault.jpg"
       },
       "high": {
        "url": "https://i.ytimg.com/vi/rKx2jESqcVc/hqdefault.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    },
    {
     "kind": "youtube#searchResult",
     "etag": "\"VpnTb8s3E3Zgj053RWwtg-Ly9AA/ds6U0fK8DyfLoqIplJ0sQ1LMg8g\"",
     "id": {
      "kind": "youtube#channel",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ"
     },
     "snippet": {
      "publishedAt": "2012-03-14T15:29:16.000Z",
      "channelId": "UCswDowOOvJ-fkCgH9YAITjQ",
      "title": "Upworthy",
      "description": "At best, things online are usually either awesome or meaningful, but everything on Upworthy.com has a little of both. Sensational and substantial. Entertaini...",
      "thumbnails": {
       "default": {
        "url": "https://lh3.googleusercontent.com/-XY51_-C9udA/AAAAAAAAAAI/AAAAAAAAAAA/0Z_IeSugaQk/photo.jpg"
       },
       "medium": {
        "url": "https://lh3.googleusercontent.com/-XY51_-C9udA/AAAAAAAAAAI/AAAAAAAAAAA/0Z_IeSugaQk/photo.jpg"
       },
       "high": {
        "url": "https://lh3.googleusercontent.com/-XY51_-C9udA/AAAAAAAAAAI/AAAAAAAAAAA/0Z_IeSugaQk/photo.jpg"
       }
      },
      "channelTitle": "upworthy",
      "liveBroadcastContent": "none"
     }
    }
   ]
  }
]}